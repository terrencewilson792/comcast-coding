/*
 	Author: Terrence Wilson
 	Program: AdServer.java
 	
	Send requests like this: 
	1) Get all ads -> curl -XGET -H 'Content-Type:application/json' http://<server>:80/ad/
	2) Get ads by partner_id -> curl -XGET -H 'Content-Type:application/json' http://<server>:80/ad/<partner_id>/
	3) Post an ad -> curl -XPOST -H 'Content-Type:application/json' --data-binary @test.json http://<server>:80/ad/
*/

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import org.json.simple.parser.JSONParser;
import java.net.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.ZonedDateTime;
import java.io.*;

public class AdServer {
	final static String ADD_DIR = "ad_files";
	static File fileDir = null;
	public static void main(String args[]) throws ParseException {		
				
		try {
			fileDir = new File(ADD_DIR);
			if(!fileDir.exists()) {
				fileDir.mkdir();
			}
		    HttpServer server = HttpServer.create(new InetSocketAddress(80), 0);
		    server.createContext("/", new MyHandler());
		    server.setExecutor(null); // creates a default executor
		    server.start();			
		    System.out.println("Listening for ad requests at port " + server.getAddress().getPort());
			
		} catch(IOException ex) {
			ex.printStackTrace();
		}		
	}
	
	static class MyHandler implements HttpHandler {
	    public void handle(HttpExchange t) throws IOException {	 
	    	StringBuilder sb = null;
	    	String oldData = "";
	    	String reqBody = "";
	    	String reqPath = t.getRequestURI().getPath().substring(1, t.getRequestURI().getPath().length());
		    System.out.println("Request path: "+reqPath+"; Request type: "+t.getRequestMethod());
		    if((!"".equals(reqPath)) && ("ad/".equals(reqPath.substring(0, 3)))) {
		    	if("GET".equals(t.getRequestMethod())) {		    		
		    		String[] reqParams = reqPath.substring(0,reqPath.length()-1).split("/");
		    		File[] list = fileDir.listFiles();
		    		if(reqParams.length > 1) {
						BufferedReader br = null;	    	
						sb = new StringBuilder();
		    						
						String line;
						
						br = new BufferedReader(new InputStreamReader(t.getRequestBody()));
						while ((line = br.readLine()) != null) {
							sb.append(line);
						}	    	
						
						reqBody  = sb.toString();
						oldData = getPartnerAds(list, reqParams[1], sb, reqBody, t);
		    		} else {
		    			reqBody = getAllAds(list);
		    		}
		    	} else {
		    		BufferedReader br = null;
		    		sb = new StringBuilder();
		
		    		String line;
		    		try {
		
		    			br = new BufferedReader(new InputStreamReader(t.getRequestBody()));
		    			while ((line = br.readLine()) != null) {
		    				sb.append(line);
		    			}
		    			
		    			System.out.println(sb.toString());
		    			JSONParser parser = new JSONParser();
		    			JSONObject obj = (JSONObject) parser.parse(sb.toString());
		    			String partnerId = (String)obj.get("partner_id");
		    			String duration = (String)obj.get("duration");
		    			String adContent = (String)obj.get("ad_content");
		
		    			long secs = ZonedDateTime.now().toInstant().toEpochMilli();
		    			reqBody = partnerId+"\n"+duration+"\n"+adContent+"\n"+secs;
		    			
						System.out.println("Creating ad dir...");
		    			File[] list = fileDir.listFiles();
		    	        if(list.length != 0) {
		    	        	oldData = getPartnerAds(list, partnerId, sb, reqBody, t);
		    	        	createAdFile(partnerId, reqBody);
		    	        } else {
							System.out.println("Entering createAdFile()...");
		    	        	createAdFile(partnerId, reqBody);
		    	        }
		    		} catch (IOException | ParseException e) {
		    			e.printStackTrace();
		    		} finally {
		    			if (br != null) {
		    				try {
		    					br.close();
		    				} catch (IOException e) {
		    					e.printStackTrace();
		    				}
		    			}
		    		}	    	
		    	}
		    	if((reqBody.length() > 0) && ("\n".equals(reqBody.substring(0, 1)))) {
		    		reqBody = reqBody.substring(1, reqBody.length()-1);
		    	}
		    	oldData += reqBody;
		    	sendResponse(t, oldData);
		    } else {
		    	oldData = "This path is not unavailable!";	
		    	sendResponse(t, oldData);
		    }
	    }
	    
	    private String getPartnerAds(File[] list, String partnerId, StringBuilder sb, String response, HttpExchange t) throws IOException {
        	String oldData = "";
	        for (File fil : list) {
	        	String filename = fil.getName();
	        	String fileNameTrunk = filename.substring(0, filename.length()-4);
	        	if(fileNameTrunk.equals(partnerId)) {
	        		sb = new StringBuilder();
    	        	String line = "";
    	        	filename = ADD_DIR+"//"+filename;
	    			BufferedReader br2 = new BufferedReader(new FileReader(filename));
	    			while ((line = br2.readLine()) != null) {
	    				sb.append(line+"\n");
	    			}		 
	    			br2.close();
	    			String adData = sb.toString();
	    			System.out.println("String to parse: "+adData);
	    			String[] ads = adData.split("EOA");
	    			
	    			for(int i=0; i<ads.length; i++) {
		    			int count = 0;
		    			String dur = "";				    				
	    				StringTokenizer st = new StringTokenizer(ads[i], "\n");	
	    				while(st.hasMoreTokens()) {
	    					String token = st.nextToken();
	    	        		if(count == 1) {
	    	        			dur = token;
	    	        			System.out.println(Long.valueOf(dur)*1000);
	    	        			oldData += dur+"\n";
	    	        		} else if(count == 3) {
	    	        			long adAge = ZonedDateTime.now().toInstant().toEpochMilli() - Long.valueOf(token);
	    	        			System.out.println("Time passed since first add: "+ (adAge));
	    	        			if((adAge) > (Long.valueOf(dur)*1000)) {
	    	        				oldData += token+" -> Ad has expired!"+"\n";
	    	        			}
	    	        		} else {
	    	        			oldData += token+"\n";
	    	        		}
	    	        		count++;	
	    				}
	    			}
	    			
	    			System.out.println("Appending to file!");			    			
	    			response = "\nEOA\n"+response;
	    			System.out.println("Request type: "+t.getRequestMethod()+"; response: "+response);	
	    			if("POST".equals(t.getRequestMethod())) {
	    				Files.write(Paths.get(filename), response.getBytes(), StandardOpenOption.APPEND);
	    			}
    	        	break;
	        	}
	        }
        	return oldData;
	    }

	    private String getAllAds(File[] list) throws IOException {
        	StringBuilder sb = null;
        	JSONObject objOuter = new JSONObject();
        	
	        for (File fil : list) {
	        	String filename = fil.getName();
	        	String fileNameTrunk = filename.substring(0, filename.length()-4);	    	
	    		sb = new StringBuilder();
	        	String line = "";
	        	filename = ADD_DIR+"//"+filename;
				BufferedReader br2 = new BufferedReader(new FileReader(filename));
				while ((line = br2.readLine()) != null) {
					sb.append(line+"\n");
				}		 
				br2.close();
				String adData = sb.toString();
				System.out.println("String to parse: "+adData);
				String[] ads = adData.split("EOA");
				JSONObject objInner = new JSONObject();
				for(int i=0; i<ads.length; i++) {
	    			int count = 0;
	    			String dur = "";				    				
					StringTokenizer st = new StringTokenizer(ads[i], "\n");	
					while(st.hasMoreTokens()) {
						String token = st.nextToken();
		        		if(count == 1) {
		        			dur = token;
		        			objInner.put("duration", token);
		        		} else if(count == 3) {		        			
		        			long adAge = ZonedDateTime.now().toInstant().toEpochMilli() - Long.valueOf(token);
		        			objInner.put("age", adAge);
		        			if((adAge) > (Long.valueOf(dur)*1000)) {
		        			}
		        		} else {
		        			if(count == 0) {
		        				objInner.put("partner_id", token);
		        			} else {
		        				objInner.put("ad_content", token);
		        			}
		        		}
		        		count++;	
					}
					objOuter.put(fileNameTrunk, (JSONObject)objInner);
				}
	        }
	        return objOuter.toJSONString();
	    }
	    
	    private void createAdFile(String partnerId, String reqBody) throws IOException {
        	System.out.println("Creating new ad file!");
    		BufferedWriter bw = null;
    		FileWriter fw = null;	    	        	
			fw = new FileWriter(ADD_DIR+"//"+partnerId+".txt");
			bw = new BufferedWriter(fw);
			bw.write(reqBody);
			bw.close();
			fw.close();	    	
	    }

	    public void sendResponse(HttpExchange t, String oldData) throws IOException {
	        t.sendResponseHeaders(200, oldData.length());
	        OutputStream os = t.getResponseBody();
	        os.write(oldData.getBytes());
	        os.close();	    	
	    }
	    
	}	

}	
